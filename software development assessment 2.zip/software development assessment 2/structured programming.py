print('\n\t\tStructured programming part 1\n\t')
f= open('3224849a.csv','r')
#counters set up
count=0
countinvalidcode=0
count4q2=0
per4q2=0
countvotes=0
per_votes=0
countcolour=0
countq5=0
countq6=0
total=0
average=0
countq7=0
for line in f:
    line= line.strip()
    fields=line.split(',')
    weight=float(fields[1])
    votes=int(fields[2])
    colour=fields[3]
    val= fields[4]
    ages= int(fields[5])
    


            
#q2
    count +=1
    if weight >= 1544.505 and weight <= 1795.023:
        count4q2 +=1

##q3
    count+=1
    if votes >= 1125:
        countvotes+=1
        


#q4
        
    if len(colour) >3:
        countcolour +=1
        
#q5
    count+=1
    if  val == 'cold':
        countq5 +=1

##q6
    if ages>= 38 and ages<= 74:
        total += ages
        countq6+=1
       
## q7 count the lines where val's have the value [hot] or votes is less than 1508
    count+=1
    if val == 'hot' or votes <1508:
        countq7+=1

f.close()
per4q2=(count4q2/count)*100
print('Q2.Percentage of numbers in KG:%.2f'% per4q2)
per_votes=(countvotes/count)*100
print('Q3.percentage of numbers in votes equal to 1125',per_votes)
print ('Q4.colour of length is 3:',countcolour)
print ('Q5.There are %d Cold' % (countq5))
average = total/ages
print('Q6.average of ages:%.2f'%(average ))
average=total/countq7
print('Q7. count value is hot and votes are %d less than 1508'%(countq7))


   
    
